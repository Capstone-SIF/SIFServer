import os

config = {
	'num_sensors': 3,
	'rootPath': os.path.abspath('.'),
}